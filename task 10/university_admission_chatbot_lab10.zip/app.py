
from flask import Flask, render_template, request, jsonify
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.neural_network import MLPClassifier

app = Flask(__name__)

# Training data (intents)
training_sentences = [
    "what programs do you offer",
    "which degrees are available",
    "tell me about programs",
    "what are admission requirements",
    "how can I apply",
    "what documents are needed",
    "when is the admission deadline",
    "last date for admission",
    "when do admissions close",
    "hello",
    "hi",
    "bye"
]

labels = [
    "programs",
    "programs",
    "programs",
    "requirements",
    "requirements",
    "requirements",
    "deadline",
    "deadline",
    "deadline",
    "greeting",
    "greeting",
    "bye"
]

# Vectorization
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(training_sentences)

# Simple ANN classifier
model = MLPClassifier(hidden_layer_sizes=(10,), max_iter=1000)
model.fit(X, labels)

# Responses
responses = {
    "programs": "We offer BS Artificial Intelligence, BS Computer Science, and BS Data Science.",
    "requirements": "Admission requires FSC/ICS or equivalent with minimum 50% marks and entry test.",
    "deadline": "Admissions usually close on August 30 each year.",
    "greeting": "Hello! I am the University Admission Bot. How can I help you?",
    "bye": "Goodbye! If you have more questions about admissions, feel free to ask."
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    message = request.json["message"]
    vect = vectorizer.transform([message])
    prediction = model.predict(vect)[0]
    reply = responses.get(prediction, "Sorry, I don't understand. Please ask about admissions.")
    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(debug=True)

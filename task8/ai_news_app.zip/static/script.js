async function getNews(){

let topic = document.getElementById("topic").value;

let response = await fetch("/get_news",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({topic:topic})
});

let data = await response.json();

let newsDiv = document.getElementById("news");
newsDiv.innerHTML="";

data.forEach(article => {

newsDiv.innerHTML += `
<div class="card">
<h3>${article.title}</h3>
<p>${article.description}</p>
<a href="${article.url}" target="_blank">Read More</a>
</div>
`;

});

}

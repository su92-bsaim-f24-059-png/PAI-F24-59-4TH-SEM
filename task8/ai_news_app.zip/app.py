from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

API_KEY = "YOUR_NEWS_API_KEY"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_news", methods=["POST"])
def get_news():
    topic = request.json["topic"]

    url = f"https://newsapi.org/v2/everything?q={topic}&apiKey={API_KEY}"

    response = requests.get(url)
    data = response.json()

    articles = []

    for article in data.get("articles", [])[:5]:
        articles.append({
            "title": article.get("title"),
            "description": article.get("description"),
            "url": article.get("url")
        })

    return jsonify(articles)

if __name__ == "__main__":
    app.run(debug=True)

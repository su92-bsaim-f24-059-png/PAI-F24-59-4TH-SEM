# ============================================================
# GENERATIVE AI COMPLETE PROJECT
# Programming for Artificial Intelligence - Lab 11
# Topic: Generative Artificial Intelligence (GenAI)
# ============================================================

import numpy as np
import faiss

from transformers import pipeline
from sentence_transformers import SentenceTransformer

print("\n================================================")
print("      GENERATIVE AI COMPLETE PROJECT")
print("================================================")
print("Programming for Artificial Intelligence")
print("Lab 11 Project")
print("================================================\n")

# ============================================================
# SECTION 1 - TEXT GENERATION
# ============================================================

print("\nSECTION 1 - TEXT GENERATION\n")

text_generator = pipeline(
    "text-generation",
    model="gpt2"
)

prompt = "Artificial Intelligence will transform the future because"

result = text_generator(
    prompt,
    max_length=80,
    num_return_sequences=1
)

print(result[0]['generated_text'])

# ============================================================
# SECTION 2 - QUESTION ANSWERING
# ============================================================

print("\nSECTION 2 - QUESTION ANSWERING\n")

qa_pipeline = pipeline("question-answering")

context = """
Artificial Intelligence is a branch of computer science.
Machine Learning is a subset of Artificial Intelligence.
Deep Learning uses neural networks for solving complex problems.
"""

question = "What does Deep Learning use?"

answer = qa_pipeline(
    question=question,
    context=context
)

print(answer['answer'])

# ============================================================
# SECTION 3 - SENTIMENT ANALYSIS
# ============================================================

print("\nSECTION 3 - SENTIMENT ANALYSIS\n")

sentiment_pipeline = pipeline("sentiment-analysis")

review = "This AI project is amazing and very powerful!"

sentiment_result = sentiment_pipeline(review)

print(sentiment_result)

# ============================================================
# SECTION 4 - SUMMARIZATION
# ============================================================

print("\nSECTION 4 - SUMMARIZATION\n")

summarizer = pipeline("summarization")

long_text = """
Artificial Intelligence is one of the fastest growing fields in technology.
It is transforming industries such as healthcare, education, finance,
entertainment, and cybersecurity.
"""

summary = summarizer(
    long_text,
    max_length=40,
    min_length=15,
    do_sample=False
)

print(summary[0]['summary_text'])

# ============================================================
# SECTION 5 - VECTOR EMBEDDINGS
# ============================================================

print("\nSECTION 5 - VECTOR EMBEDDINGS\n")

embedding_model = SentenceTransformer(
    'all-MiniLM-L6-v2'
)

sentences = [
    "Artificial Intelligence is powerful.",
    "Machine Learning is a subset of AI.",
    "Deep Learning uses neural networks.",
    "Python is popular for AI development."
]

embeddings = embedding_model.encode(sentences)

print("Embedding Shape:")
print(embeddings.shape)

# ============================================================
# SECTION 6 - VECTOR DATABASE USING FAISS
# ============================================================

print("\nSECTION 6 - VECTOR DATABASE\n")

vector_dimension = embeddings.shape[1]

index = faiss.IndexFlatL2(vector_dimension)

index.add(np.array(embeddings))

print("Total Vectors Stored:", index.ntotal)

# ============================================================
# SECTION 7 - SEMANTIC SEARCH
# ============================================================

print("\nSECTION 7 - SEMANTIC SEARCH\n")

query = "Explain AI models"

query_embedding = embedding_model.encode([query])

k = 2

distances, indices = index.search(
    np.array(query_embedding),
    k
)

for i in range(k):

    idx = indices[0][i]

    print(f"Rank #{i+1}")
    print("Sentence:", sentences[idx])
    print("Distance Score:", distances[0][i])
    print("-----------------------------------")

# ============================================================
# SECTION 8 - RAG SYSTEM
# ============================================================

print("\nSECTION 8 - RAG SYSTEM\n")

knowledge_base = [
    "Artificial Intelligence enables machines to think.",
    "Machine Learning learns patterns from data.",
    "Generative AI creates new content automatically."
]

kb_embeddings = embedding_model.encode(knowledge_base)

rag_index = faiss.IndexFlatL2(kb_embeddings.shape[1])

rag_index.add(np.array(kb_embeddings))

rag_query = "What is Generative AI?"

rag_query_vector = embedding_model.encode([rag_query])

D, I = rag_index.search(np.array(rag_query_vector), 1)

retrieved_document = knowledge_base[I[0][0]]

print("Retrieved Knowledge:")
print(retrieved_document)

rag_prompt = f"Question: {rag_query}\\nInformation: {retrieved_document}\\nAnswer:"

rag_response = text_generator(
    rag_prompt,
    max_length=70
)

print(rag_response[0]['generated_text'])

# ============================================================
# FINAL CONCLUSION
# ============================================================

print("\n================================================")
print("PROJECT EXECUTED SUCCESSFULLY")
print("================================================\n")

GENERATIVE AI COMPLETE PROJECT
================================

HOW TO RUN PROJECT

1. Install Python

2. Install Required Libraries:

pip install transformers
pip install sentence-transformers
pip install faiss-cpu
pip install torch
pip install numpy

3. Run Project:

python generative_ai_project.py

PROJECT FEATURES
----------------
- Text Generation
- Question Answering
- Sentiment Analysis
- Summarization
- Vector Embeddings
- FAISS Vector Database
- Semantic Search
- RAG System

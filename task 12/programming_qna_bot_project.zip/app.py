from flask import Flask, render_template, request

import pandas as pd
import numpy as np
import faiss

from sentence_transformers import SentenceTransformer

# ============================================================
# LOAD DATASET
# ============================================================

data = pd.read_csv("dataset.csv")

questions = data["Question"].tolist()
answers = data["Answer"].tolist()

# ============================================================
# LOAD HUGGING FACE MODEL
# ============================================================

model = SentenceTransformer(
    'paraphrase-MiniLM-L6-v2'
)

# ============================================================
# CREATE EMBEDDINGS
# ============================================================

question_embeddings = model.encode(questions)

# ============================================================
# CREATE FAISS INDEX
# ============================================================

dimension = question_embeddings.shape[1]

index = faiss.IndexFlatL2(dimension)

index.add(np.array(question_embeddings))

# ============================================================
# FLASK APP
# ============================================================

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():

    result = ""

    if request.method == "POST":

        user_query = request.form["query"]

        query_embedding = model.encode([user_query])

        distances, indices = index.search(
            np.array(query_embedding),
            1
        )

        matched_index = indices[0][0]

        result = answers[matched_index]

    return render_template(
        "index.html",
        result=result
    )

if __name__ == "__main__":

    app.run(debug=True)

Programming QnA Bot
=====================

HOW TO RUN

1. Install libraries:

pip install -r requirements.txt

2. Run project:

python app.py

3. Open browser:

http://127.0.0.1:5000

FEATURES
--------
- Flask UI
- Hugging Face MiniLM
- FAISS Vector Search
- Semantic QnA Bot

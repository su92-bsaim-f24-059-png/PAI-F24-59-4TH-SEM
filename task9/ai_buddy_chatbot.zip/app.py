
from flask import Flask, render_template, request, jsonify
from textblob import TextBlob

app = Flask(__name__)

def get_response(user_text):
    text = user_text.lower()

    if "hello" in text or "hi" in text:
        return "Hello! I am your AI Buddy. How are you today?"
    
    if "how are you" in text:
        return "I am doing great! Tell me something about your day."
    
    if "study" in text or "ai" in text:
        return "That's awesome! Studying AI is a great career choice."
    
    if "bye" in text:
        return "Goodbye! Have a great day."

    analysis = TextBlob(user_text)
    polarity = analysis.sentiment.polarity

    if polarity > 0:
        return "You sound happy today! 😊"
    elif polarity < 0:
        return "I'm sorry you're feeling that way. Things will get better."
    else:
        return "Tell me more about that."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_text = request.json["message"]
    response = get_response(user_text)
    return jsonify({"reply": response})

if __name__ == "__main__":
    app.run(debug=True)
